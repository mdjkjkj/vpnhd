# 🛡️ WireGuard VPN Auto Setup (Bare-metal)

A complete script to set up your own **WireGuard VPN server** automatically on any Ubuntu/Debian VPS.

---

## ⚡ Features
- Fully automated WireGuard installation
- Auto firewall (UFW) setup
- Auto server key generation
- One-command client creation
- QR code generation for mobile import
- Optional GitHub Actions deployment

---

## 🚀 Quick Start
```bash
git clone https://github.com/yourusername/wireguard-vpn-auto-setup.git
cd wireguard-vpn-auto-setup
chmod +x install-wireguard.sh add-client.sh
sudo bash install-wireguard.sh
sudo bash add-client.sh myphone
```

---

## ⚙️ GitHub Actions Setup

Add these Secrets in your GitHub repo → Settings → Secrets → Actions:

| Secret Name | Description |
|--------------|-------------|
| VPS_HOST | Your VPS IP |
| VPS_USER | Your SSH username |
| VPS_SSH_KEY | Your private SSH key |
| VPS_SSH_PORT | Default 22 |

---

## ⚠️ Legal Notice
For educational and personal VPN setup only. Use responsibly.
