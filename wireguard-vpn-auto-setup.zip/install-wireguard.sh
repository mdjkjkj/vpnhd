#!/bin/bash
# ===============================================
# WireGuard VPN auto-install script (Bare-metal)
# Tested on Ubuntu 22.04 / Debian 12
# Author: mdmorshed islam (for GitHub use)
# ===============================================

set -e

SERVER_IP=$(curl -s ifconfig.me)
SERVER_PORT=51820
WG_INTERFACE="wg0"
WG_PATH="/etc/wireguard"

echo "==> Updating system..."
apt update && apt upgrade -y

echo "==> Installing WireGuard..."
apt install -y wireguard qrencode ufw curl

echo "==> Generating server keys..."
umask 077
wg genkey | tee $WG_PATH/server_private.key | wg pubkey > $WG_PATH/server_public.key

SERVER_PRIV=$(cat $WG_PATH/server_private.key)
SERVER_PUB=$(cat $WG_PATH/server_public.key)

echo "==> Creating WireGuard config..."
cat > $WG_PATH/$WG_INTERFACE.conf <<EOF
[Interface]
Address = 10.0.0.1/24
ListenPort = ${SERVER_PORT}
PrivateKey = ${SERVER_PRIV}
SaveConfig = true

PostUp = iptables -A FORWARD -i %i -j ACCEPT; iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE
PostDown = iptables -D FORWARD -i %i -j ACCEPT; iptables -t nat -D POSTROUTING -o eth0 -j MASQUERADE
EOF

echo "==> Configuring firewall..."
ufw allow ${SERVER_PORT}/udp
ufw allow OpenSSH
ufw --force enable

echo "==> Enabling WireGuard service..."
systemctl enable wg-quick@${WG_INTERFACE}
systemctl start wg-quick@${WG_INTERFACE}

echo "==> Server setup complete!"
echo "------------------------------------"
echo "Server public key: ${SERVER_PUB}"
echo "Server IP: ${SERVER_IP}:${SERVER_PORT}"
echo "------------------------------------"
echo ""
echo "To add new clients: bash add-client.sh clientname"
