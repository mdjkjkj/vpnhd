#!/bin/bash
# ===============================================
# Add WireGuard client
# Usage: bash add-client.sh clientname
# ===============================================

WG_INTERFACE="wg0"
WG_PATH="/etc/wireguard"
CLIENT_NAME=$1

if [ -z "$CLIENT_NAME" ]; then
  echo "Usage: bash add-client.sh <client_name>"
  exit 1
fi

SERVER_IP=$(curl -s ifconfig.me)
SERVER_PORT=51820
SERVER_PUB=$(cat $WG_PATH/server_public.key)

echo "==> Creating keys for $CLIENT_NAME..."
umask 077
wg genkey | tee $WG_PATH/${CLIENT_NAME}_private.key | wg pubkey > $WG_PATH/${CLIENT_NAME}_public.key

CLIENT_PRIV=$(cat $WG_PATH/${CLIENT_NAME}_private.key)
CLIENT_PUB=$(cat $WG_PATH/${CLIENT_NAME}_public.key)

# auto-assign IP (10.0.0.X)
LAST_IP=$(grep -oP '10\.0\.0\.\K[0-9]+' $WG_PATH/wg0.conf | sort -n | tail -1)
if [ -z "$LAST_IP" ]; then
  CLIENT_IP="10.0.0.2"
else
  CLIENT_IP="10.0.0.$((LAST_IP + 1))"
fi

cat > $WG_PATH/${CLIENT_NAME}.conf <<EOF
[Interface]
PrivateKey = ${CLIENT_PRIV}
Address = ${CLIENT_IP}/32
DNS = 1.1.1.1

[Peer]
PublicKey = ${SERVER_PUB}
Endpoint = ${SERVER_IP}:${SERVER_PORT}
AllowedIPs = 0.0.0.0/0, ::/0
PersistentKeepalive = 25
EOF

echo "==> Adding client to server config..."
wg set ${WG_INTERFACE} peer ${CLIENT_PUB} allowed-ips ${CLIENT_IP}/32
wg-quick save ${WG_INTERFACE}

echo "==> Client ${CLIENT_NAME} added successfully!"
echo "------------------------------------"
qrencode -t ansiutf8 < $WG_PATH/${CLIENT_NAME}.conf
echo "------------------------------------"
echo "Config file saved at: $WG_PATH/${CLIENT_NAME}.conf"
